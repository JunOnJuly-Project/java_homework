package dto;

import java.io.Serializable;

public class Profile implements Serializable {
	private String name;
	private int weight;
	private String password;
	
	public Profile(String name, int weight, String password) {
		super();
		this.name = name;
		this.weight = weight;
		this.password = password;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(name);
		builder.append("님의 몸무게는 ");
		builder.append(weight);
		builder.append("kg 이고 비밀번호는 ");
		builder.append(password);
		builder.append("입니다.");
		return builder.toString();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
