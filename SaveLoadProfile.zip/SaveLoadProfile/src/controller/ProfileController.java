package controller;

import dto.Profile;

import service.ProfileService;
import service.ProfileServiceIMPL;

import exception.*;

public class ProfileController {
	private ProfileService service = ProfileServiceIMPL.getInstance();
	
	public void saveProfile() {
		service.saveProfile();
	}
	
	public void loadProfile() {
		service.loadProfile();
	}
	
	public void insert(Profile profile) {
		try {
			service.insert(profile);
		} catch (DuplicateException e) {
			
		}
	}
}
