package service;

import dto.Profile;
import exception.*;

import java.io.*;
import java.util.*;

public class ProfileServiceIMPL implements ProfileService {
	private final static String SAVE_PATH = "resources/profileList.txt";
	private static ProfileService instance = new ProfileServiceIMPL();
	private List<Profile> profiles;
	private int errorCnt = 0;
	
    public static ProfileService getInstance() {
		return instance;
	}
    
	/**
	 * 저장된 객체 불러오기
	 */
	public ProfileServiceIMPL(){
		
		loadProfile();
	}

	@Override
	public void saveProfile() {
		
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(SAVE_PATH))) {
			oos.writeObject(oos);
		} catch (Exception e) {}
	}

	@Override
	public void loadProfile() {
		
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(SAVE_PATH))) {
			profiles = (ArrayList<Profile>) ois.readObject();
		} catch (Exception e) {
			profiles = new ArrayList<Profile>();
		}
	}

	@Override
	public void insert(Profile profile) throws DuplicateException {
		
		for (Profile p : profiles) {
			if (p.getName().equals(profile.getName())) {
				throw new DuplicateException("중복된 이름은 사용할 수 없습니다.");
			}
		}
		
		profiles.add(profile);
	}

	@Override
	public Profile searchByName(String name, String password) throws NameNotFoundException, PasswordDiscordException {
		
		for (Profile p : profiles) {
			if (p.getName().equals(name)) {
				if (p.getPassword().equals(password) != true) {
					if (errorCnt >= 3) {
						throw new PasswordDiscordException("비밀번호를 3회 틀렸습니다. 처음으로 돌아갑니다.");
					}
					
					else {
						throw new PasswordDiscordException("비밀번호를 틀렸습니다. 다시 입력해주세요 " + errorCnt + "/3");
					}
				}
			}
			
			errorCnt = 0;
			return p;
		}
		
		throw new NameNotFoundException("일치하는 이름이 없습니다.");
	}

	@Override
	public void updateWeight(String name, String password, int weight)
			throws NameNotFoundException, PasswordDiscordException {
		
		for (Profile p : profiles) {
			if (p.getName().equals(name)) {
				if (p.getPassword().equals(password) != true) {
					if (errorCnt > 3) {
						throw new PasswordDiscordException("비밀번호를 3회 틀렸습니다. 처음으로 돌아갑니다.");
					}
					
					else {
						throw new PasswordDiscordException("비밀번호를 틀렸습니다. 다시 입력해주세요 " + errorCnt + "/3");
					}
				}
			}
			
			errorCnt = 0;
			p.setWeight(weight);
		}
		
		throw new NameNotFoundException("일치하는 이름이 없습니다.");
	}

	@Override
	public void updatePassword(String name, String password, String newPassword)
			throws NameNotFoundException, PasswordDiscordException, PasswordUnchangedException {
		
		for (Profile p : profiles) {
			if (p.getName().equals(name)) {
				if (p.getPassword().equals(password) != true) {
					if (errorCnt > 3) {
						throw new PasswordDiscordException("비밀번호를 3회 틀렸습니다. 처음으로 돌아갑니다.");
					}
					
					else {
						throw new PasswordDiscordException("비밀번호를 틀렸습니다. 다시 입력해주세요 " + errorCnt + "/3");
					}
				}
			}
			
			errorCnt = 0;
			p.setPassword(password);
		}
		
		throw new NameNotFoundException("일치하는 이름이 없습니다.");
	}
}
