package view;

public class FailView {

	public static void printFailMessage (String message) {
		System.out.println("----- " + message + " -----");
	}
}
