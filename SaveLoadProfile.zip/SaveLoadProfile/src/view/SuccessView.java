package view;

import dto.Profile;

public class SuccessView {

	public static void printSuccessMessage (String message) {
		System.out.println("++++++++++++++++++++");
		System.out.println(message);
		System.out.println("++++++++++++++++++++");
	}
	
	public static void printSearchByName (Profile profile) {
		System.out.printf("현재 %s 님의 몸무게는 %dkg 입니다", profile.getName(), profile.getWeight());
	}
}
