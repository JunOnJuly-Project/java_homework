package view;

import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;

import controller.ProfileController;

/**
   사용자의 요청을 키보드로 입력받는 클래스 
*/
public class MenuView{
    Scanner sc= new Scanner(System.in);
	ProfileController controller = new ProfileController(); // 전역변수 초기화, 생성자 호출 
	/**
	  전체 메뉴를 출력하는 메소드
	*/
	public void printMenu(){
        
		 while(true){
			 System.out.println("-------------------------------------------------------------------------------------------------------------");
			 System.out.println("1. 몸무게 입력    2. 몸무게 검색     3. 몸무게 변경     4. 비밀번호 변경   5. 프로그램 종료");
			 System.out.println("-------------------------------------------------------------------------------------------------------------");
			 System.out.print("메뉴선택 > ");

			 String  menu = sc.nextLine();
			 switch(menu){
			 case "1" : 
				 insertProfile();
				 break;
			 case "2" : 
	             this.inputSearch();
				 break;
			 case "3" : 
	             this.inputInsert();
				 break;
			 case "4" : 
	             this.inputUpdate();
				 break;
			 case "5" : 
				 saveProfile();
				 System.exit(0);
			 default:
				 System.out.println("메뉴를 다시 선택해주세요!!!!");

			   }//switch문끝

			 }//while문끝
	
	}//메소드끝
	
	/**
	 * 상태 저장
	 */
	public void saveProfile() {
		controller.saveProfile();
	}
	
	/**
	 * 프로필 입력
	 */
	public void insertProfile() {
		System.out.print("이름을 입력해주세요 : ");
		String name = sc.nextLine();
		
		System.out.print("몸무게을 입력해주세요 : ");
		int weight = 
	}
}