package exception;

public class PasswordUnchangedException extends Exception {

	public PasswordUnchangedException() {}

	public PasswordUnchangedException(String message) {
		super(message);
	}
}
