package exception;

public class PasswordDiscordException extends Exception {

	public PasswordDiscordException() {}
	
	public PasswordDiscordException(String message) {
		super(message);
	}
}
