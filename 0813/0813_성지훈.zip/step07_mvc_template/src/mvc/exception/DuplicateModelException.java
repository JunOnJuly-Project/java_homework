package mvc.exception;

/**
 * 모델번호가 중복되었을 때
 */
public class DuplicateModelException extends Exception {
	public DuplicateModelException() {}
	public DuplicateModelException(String message) {
		super(message);
	}
}
