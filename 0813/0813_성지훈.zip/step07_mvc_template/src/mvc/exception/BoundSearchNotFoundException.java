package mvc.exception;

public class BoundSearchNotFoundException extends Exception {
	public BoundSearchNotFoundException() {}

	public BoundSearchNotFoundException(String message) {
		super(message);
	}
}
