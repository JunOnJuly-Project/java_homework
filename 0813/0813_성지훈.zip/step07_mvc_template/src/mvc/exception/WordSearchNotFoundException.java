package mvc.exception;

public class WordSearchNotFoundException extends Exception {
	public WordSearchNotFoundException() {
		
	}
	public WordSearchNotFoundException(String message) {
		super(message);
	}
}
