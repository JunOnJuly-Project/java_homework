package ex0729.homework;

public class Exersise05 {

	public static void main(String[] args) {
		int value = 356;
		System.out.println(100*(value/100));
	}
}