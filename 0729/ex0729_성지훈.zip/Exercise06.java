package ex0729.homework;

public class Exercise06 {

	public static void main(String[] args) {
		int lengthTop = 5;
		int lengthBottom = 10;
		int height = 7;
		
		double area = (double) (lengthTop+lengthBottom) * height / 2; 
		
		System.out.println(area);
	}
}